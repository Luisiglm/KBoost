function [L loglik] = Eval_Out_Layer(X,Y,L)



L.H = X*L.W + repmat(L.A,size(Y,1),1);


if strcmp(L.T,'reg')
    
    L.Z = L.H;
    
    loglik.see = sum((Y-L.Z ).^2);
    
    loglik.e =  Y-L.Z;
    

    
elseif strcmp(L.T,'lognorm')
    
    
elseif strcmp(L.T,'exp')
    
    
elseif strcmp(L.T,'enc')
    
        
    L.Z = L.H;
    
    L.Extra.H_m = std(L.Z);
    
    L.Extra.W_v = 0;

    L.Extra.X_v = 0;
    
    L.Extra.Z_m = mean(L.Z);
    
    L.act = 'none';

    
    loglik.see = 1/2*(sum(L.Extra.H_m)+sum(L.Extra.Z_m.^2)-size(L.Extra.Z_m,2)-sum(log(L.Extra.H_m)));
    
    n = size(L.Z,1);

    K = repmat((1-1./L.Extra.H_m),n,1);

    ds = -1/n^2*K.*(L.H-repmat(L.Extra.Z_m,n,1));
    
    dmu = L.Extra.Z_m/(2*n);
    
    loglik.e = (ds + repmat(dmu,n,1));
    
    
    
  
    
    
elseif strcmp(L.T,'class')
    

    if size(Y,2)>1
    
    if sum(isinf(exp(L.H)),'all')>0
        
       infin =  isinf(exp(L.H));
        
       L.H(infin) = 20;
    end
        
        L.Z = exp(L.H)./(repmat(sum(exp(L.H),2),1,size(L.H,2)));
    
    

    loglik.e = (Y-L.Z);
    
    Mat = zeros(size(Y,1),size(Y,2));
        
    [~,Maxs] = max(L.Z,[],2);
    
    for j = 1:size(Y,1)
        
       Mat(j,Maxs(j)) = 1;
        
    end
    
    loglik.acc = sum(Mat.*Y,'all')/size(Y,1);
    
    else
        
        L.Z = 1./(1 + exp(-L.H));
        
        loglik.e = (Y-L.Z);
        
    end
    

    loglik.see = sum(log(L.Z).*Y,'all');
    
 
    
    
    
end