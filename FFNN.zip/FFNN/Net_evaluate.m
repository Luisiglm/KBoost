function Net = Net_evaluate(Net,X,Y)


% Update the weights

Net.X = X;


L = Eval_Layer(X,Net.Model(1));


Model = L;

for i = 2:(Net.depth)



L = Eval_Layer(L.Z,Net.Model(i));
  


Q = [Model;L];

Model = Q;
    
end
    

Net.Y = Y;



[L loglik] = Eval_Out_Layer(L.Z,Y,Net.Model(end));

Net.Model = [Model;L];

Net.loglik = loglik;

Net.Out = L.Z;



