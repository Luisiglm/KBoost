function L = Eval_Layer(X,L,hyper)


%% Initiate Weights and Initialize the Output

if strcmp(L.T,'fnn')
    
    H = X*L.W+repmat(L.A,size(X,1),1);
    
    L.H = H;
    
elseif strcmp(L.T,'fconv')||strcmp(L.T,'deconv')
         
     if size(X,4)>1
    
     X_v = reshape(X,size(X,1)*size(X,2),size(X,4))';
    
     else
        
         X_v = X;
         
     end

     
     L.H = X_v*L.Extra.W_v;
     
     H_m = reshape(L.H',size(L.Extra.H_m,1), size(L.Extra.H_m,2),size(L.Extra.H_m,3),size(X_v,1));
    
     L.Extra.H_m = H_m;
    
     L.Extra.X_v = X_v;
     
elseif strcmp(L.T,'enc')
    
    
    % For the Encoder layer H_m has the mean parameter
    
    L.Extra.H_m = X*L.W(:,1:size(L.W,2)/2)+repmat(L.A(:,1:size(L.W,2)/2),size(X,1),1);
    

    
     % And W_v has the log sigma2 parameter
    
      L.Extra.W_v = X*L.W(:,(size(L.W,2)/2+1):end)+repmat(L.A(:,(size(L.W,2)/2+1):end),size(X,1),1);
    
    L.Extra.X_v = 0;
    
    L.Extra.W_v_id = 0;
    
    H = L.Extra.H_m + (exp(L.Extra.W_v)).^.5;%.*normrnd(0,1,size(X,1),size(L.W,2)/2);

    L.H = H;
    
    L.Z = L.H;
    
elseif strcmp(L.T,'maxpool') 

    O =  maxpool_luis(X,hyper.stride);

    Z =O.c_im;

    L.Z_id = O.c_id;
    
       
end

if ~strcmp(L.T,'maxpool')
if strcmp(L.act,'ReLU')
    
    Z = L.H;
    
    Z(Z<0) = 0;
    

    
elseif strcmp(L.act,'sig')
    
    Z = 1./(1+exp(-L.H));
    
elseif strcmp(L.act,'tanh')

    Z = tanh(L.H);
    
elseif strcmp(L.act,'prbf')
    
    Z = exp(L.H.^2);
    
elseif strcmp(L.act,'sinc')
     
    Z = sinc(L.H);
    
elseif strcmp(L.act,'linear')
    
    
    
    Z = L.H;
    
end
end

L.Extra.Mu = mean(L.Z);

L.Extra.Sigma = var(L.Z);



if L.BN
   
    Z = (Z - repmat(mean(Z),size(Z,1),1))./(repmat(var(Z),size(Z,1),1)+0.001).^.5;
    
    
end

L.Z = Z;


if strcmp(L.T,'fconv')||strcmp(L.T,'deconv')
    
    Z_m = reshape(Z',size(L.Extra.H_m,1), size(L.Extra.H_m,2),size(L.Extra.H_m,3),size(X_v,1));
    
    
    L.Extra.Z_m = Z_m;
else
    
    L.Extra.Z_m = Z;
end






