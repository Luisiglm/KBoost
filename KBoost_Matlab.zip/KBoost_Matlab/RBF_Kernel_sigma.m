function Kernel = RBF_Kernel_sigma(X,sigma)

Dist = distSquared(X,X);

Kernel = exp(-Dist/sigma);


