function [Net] = Kernel_Gradient_Boosting_Timed_Paralelle_Prior(mRNA_Exp,TFs,v,sigma,Max_Level,Prior)


%% Discard Genes that are not expressed in all samples
n = size(mRNA_Exp,1);
% 
% x = mRNA_Exp + repmat(min(mRNA_Exp),n,1);
% sum(x)
% Keepers = find(sum(x)>0);
% 
% if length(Keepers)<size(mRNA_Exp,2)
% 
% N_TFs = find(ismember(Keepers,TFs));
% 
% 
% I_TFs = find(ismember(TFs,Keepers));
% 
% 
% TFs = N_TFs;
% 
% mRNA_Exp = mRNA_Exp(:,Keepers);
% 
% 
% Prior = Prior(Keepers,I_TFs);
% 
% end



G = size(mRNA_Exp,2);

K = length(TFs);

Net  = zeros(G,K);


mRNA_Exp = mRNA_Exp - repmat(mean(mRNA_Exp), n , 1);

mRNA_Exp = mRNA_Exp./(repmat(std(mRNA_Exp),n,1));

%% Calculate Kernels and initialize model

PCAs = cell(K,1);

f = zeros(n,G);

Ls = cell(K,1);

RSS = Net;

Prev= Net;

Total = zeros(G,1);

C = sum((mRNA_Exp - repmat(mean(mRNA_Exp),n,1)).^2);

Binary = Net;

for i = 1:K
        

    Kernel = RBF_Kernel_sigma(mRNA_Exp(:,TFs(i)),sigma);
    
    [PCAs{i,1},Ls{i,1}] = Kernel_PCA(Kernel);
    
    f_new = PCAs{i,1}*diag(Ls{i,1}.^-1)*PCAs{i,1}'*mRNA_Exp;
    
    RSS(:,i) = sum((mRNA_Exp - v*f_new).^2);
    
    RSS(TFs(i),i) = mRNA_Exp(:,i)'*mRNA_Exp(:,i);
    
    P_n = (RSS(:,i)./C').^(-(n-1)/2);
         
    P_n(TFs(i)) = 0;

        
    if i == 1
    
        I = 2:K;
        
    elseif i <K
        
        I = [1:(i-1) (i+1):K];
        
    else
        
        I = 1:(K-1);
        
    end
    
    Prior_Model = prod(1.8*[Prior(:,i)  (1- Prior(:,I))],2);
    

    Net(:,i) =P_n.*Prior_Model;
        
    Prev(:,i) = Net(:,i);
                
    Total = Total +Prev(:,i);
end

Res = mRNA_Exp - f;

for w = 1:Max_Level
    
    if w == 1
        
    
    [~,Best] = max(Prev,[],2);
        
    Model = Best;
    
    for k = 1:G
    
        Binary(k,Best(k)) = 1;
        
    end
    
    else
       
         [~,Best]  = max(Prev,[],2);
       
           for k = 1:G
    
           Binary(k,Best(k)) = 1;
        
          end
        
    end
    %% Find Minimum 
    for i = 1:G
    
    Res(:,i) = mRNA_Exp(:,i) - f(:,i);
    
    f_n = PCAs{Best(i),1}*diag(Ls{Best(i),1}.^-1)*PCAs{Best(i),1}'*Res(:,i);
    
    f(:,i) = f(:,i) + f_n*v;
    
    end
    
    Res= mRNA_Exp - f;
 
    
    for i = 1:K
               
    f_new = PCAs{i,1}*diag(Ls{i,1}.^-1)*PCAs{i,1}'*Res;
    
    RSS(:,i) = sum((mRNA_Exp - f - v*f_new).^2);
    
    RSS(TFs(i),i) = mRNA_Exp(:,i)'*mRNA_Exp(:,i);
    
    Prev(:,i) = (RSS(:,i)./C').^(-(n-1)/2);
         
    Prev(TFs(i),i) = 0;
    
    
    for j = 1:G
        
    Binary_prov = Binary(j,:);    
        
    Binary_prov(i) = 1;
    
    Binary_prov = logical(Binary_prov);
    
 
    Prior_prov = prod(1.8*Prior(j,Binary_prov),2)*prod(1.8*(1-Prior(j,~Binary_prov)));
     Prev(j,i) = Prev(j,i)*Prior_prov;
    Net(j,Binary_prov) =Prev(j,i) +Net(j,Binary_prov);
      
    end
    
    Total = Total + Prev(:,i);
        
    end
    
end
    
 

Net = Net./repmat(Total,1,K);

Net = Net.*repmat(var(Net),size(Net,1),1);

Net = Net/max(max(Net));


