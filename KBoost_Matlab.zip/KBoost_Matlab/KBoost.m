function Net = KBoost(mRNA_Exp,TFs,v,sigma,Max_Level)

G = size(mRNA_Exp,2);

K = length(TFs);

Net  = zeros(G,K);

n = size(mRNA_Exp,1);

mRNA_Exp = mRNA_Exp - repmat(mean(mRNA_Exp), n , 1);

mRNA_Exp = mRNA_Exp./(repmat(std(mRNA_Exp),n,1));

%% Calculate Kernels and initialize model

PCAs = cell(K,1);

f = zeros(n,G);

Ls = cell(K,1);

RSS = Net;

Prev= Net;

Total = zeros(G,1);

C = sum((mRNA_Exp - repmat(mean(mRNA_Exp),n,1)).^2);

Norms = cell(K,1);

for i = 1:K
    
    Kernel = RBF_Kernel_sigma(mRNA_Exp(:,TFs(i)),sigma);
   
    
    [PCAs{i,1},Ls{i,1}] = Kernel_PCA(Kernel);
    
    Norms{i,1} = diag(sum(PCAs{i,1}.^2).^-1)*PCAs{i,1}'; 
    
    f_new = PCAs{i,1}*Norms{i,1}*mRNA_Exp;
    
    RSS(:,i) = sum((mRNA_Exp - v*f_new).^2);
    
    RSS(TFs(i),i) = mRNA_Exp(:,i)'*mRNA_Exp(:,i);
    
    P_n = (RSS(:,i)./C').^(-(n-1)/2);
         
    P_n(TFs(i)) = 0;
     
    Net(:,i) =P_n +Net(:,i);
        
    Prev(:,i) = Net(:,i);
                
        Total = Total + P_n;
end

Res = mRNA_Exp - f;

for w = 1:Max_Level
    
    if w == 1
        
    
    [~,Best] = max(Prev,[],2);
    
    
    Model = Best;
    else
       
         [~,Best]  = max(Prev,[],2);
       
        M = [Model Best];
        
        Model = M;
        
    end
    %% Find Minimum 
    for i = 1:G
    
    Res(:,i) = mRNA_Exp(:,i) - f(:,i);
    
    f_n = PCAs{Best(i),1}*Norms{Best(i),1}*Res(:,i);
    
    f(:,i) = f(:,i) + f_n*v;
    
    end
    
    Res= mRNA_Exp - f;
 
    
    for i = 1:K

    f_new = PCAs{i,1}*Norms{(i),1}*Res;
    
    RSS(:,i) = sum((mRNA_Exp - f - v*f_new).^2);
    
    RSS(TFs(i),i) = mRNA_Exp(:,i)'*mRNA_Exp(:,i);
    
    Prev(:,i) = (RSS(:,i)./C').^(-(n-1)/2);
         
    Prev(TFs(i),i) = 0;
     
    for j = 1:G
        
    Net(j,[Model(j,:) i]) =Prev(j,i) +Net(j,[Model(j,:) i]);
    
    end
    
    Total = Total + Prev(:,i);
        
    end
    
end
    
 

Net = Net./repmat(Total,1,K);

Net = Net.*repmat(var(Net),G,1);

Net = Net./max(max(Net));





