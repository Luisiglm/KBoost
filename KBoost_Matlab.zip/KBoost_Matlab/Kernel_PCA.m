function [Projections,Values,V] = Kernel_PCA(Kernel)

%% Pre-step 1 Kernel Diagonalization

%n = size(Kernel,1);

%Kernel = (eye(n) - 1/n*ones(n,1)*ones(1,n))*Kernel*(eye(n) - 1/n*ones(n,1)*ones(1,n));

%Kernel = Kernel - 1/n*ones(n)*Kernel-Kernel*1/n*ones(n)+1/n*ones(n)*Kernel*1/n*ones(n);

%% Step 1 Eigendecomposition

[Vectors, Values] = eig(Kernel);


%% Step 2 Normalisation 

cutoff = 0.01;

Values = diag(Values);

Indx = find(Values > cutoff);

Indx = sort(Indx, 'descend');

Values = Values(Indx);

Vectors = Vectors(:,Indx);
V = Vectors;
Vectors = Vectors ./repmat(sum(Vectors.^2),size(Vectors,1),1);

Vectors = Vectors.*((repmat(Values', size(Vectors,1),1).^-(1/2)));

% Step 3: Projections

Projections = Kernel*Vectors;
