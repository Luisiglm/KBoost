library(testthat)
library(KBoostv)

test_check("KBoostv")
